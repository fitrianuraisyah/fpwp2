<?php 
include('template/top.php');
include('template/navigasi.php');

?>

<div id="main">
	<div class="content">
		<marquee style="background: #787878; padding:5px; color: #fff;">Welcome to travellix</marquee>
		<div id="profile">
			<img src="foto/offer_4.jpg" alt="" class="animated flipInY">
			<center>
				<h2>TIKET PESAWAT</h2>
				<hr/>
			</center>
			

		</div>
		<hr/>

		
		<br />
		<br />
		<br />
	</div>
</div>


<?php include('template/footer.php'); ?>