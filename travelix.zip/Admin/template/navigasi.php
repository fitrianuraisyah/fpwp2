
<div id="nav-wrapper">
	<div class="header_nav">Admin</div>
	<ul class="nav" id="accordion">
		<li><a href="index.php">Home</a></li>
		<li class="accordion-toggle">Konsumen</li>
		<div class="accordion-content default">
			<li><a href="entry_konsumen.php">Masukkan Data konsumen</a></li>
			<li><a href="lihatdatakonsumen.php">Lihat Data Konsumen</a></li>
		</div>
		<li class="accordion-toggle">Tujuan</li>
		<div class="accordion-content default">
			<li><a href="entry_tujuan.php">Masukkan Data Tujuan</a></li>
			<li><a href="lihatdatatujuan.php">Lihat Data Tujuan</a></li>
		</div>
		<li class="accordion-toggle">Tiket</li>
		<div class="accordion-content default">
			<li><a href="entry_tiket.php">Masukkan Data Tiket</a></li>
			<li><a href="lihatdatatiket.php">Lihat Data Tiket</a></li>
		</div>
		<li><a href="logout.php">Logout</a></li>
	</ul>
</div>
