
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Travellix</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="http://localhost/cibot/animate.css">
	<link rel="stylesheet" type="text/css" href="http://localhost/cibot/font/Oxygen.css">

	<script type="text/javascript">
		function calculate() {
		var myBox1 = document.getElementById('jumlah').value;	
		var myBox2 = document.getElementById('harga').value;
		var result = document.getElementById('total');	
		var myResult = myBox1 * myBox2;
		result.value = myResult;
      
		
	}
</script>
</head>
<body>
	<div class="container">