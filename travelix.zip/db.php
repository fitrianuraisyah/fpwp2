<?php 

//$koneksi = mysqli_connect("server","user","sandi","database");
$koneksi = mysqli_connect("127.0.0.1","root","","pesawat");
//cek koneksi
if (mysqli_connect_error()) {
	echo "koneksi database gagal :".mysqli_connect_error();
}

 ?>