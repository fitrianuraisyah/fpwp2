<?php
include ("db.php");

$sql="INSERT INTO `pemesanan`(`nama_pemesan`, `alamat_email`, `no_hp`, `tanggal_psn`, `tanggal_brngkt`, `tujuan`, `jam_brngkt`) VALUES";
$sql.="('".$_POST['nama_pemesan']."','".$_POST['alamat_email']."','".$_POST['no_hp']."','".$_POST['tanggal_psn']."','".$_POST['tanggal_brngkt']."','".$_POST['tujuan']."','".$_POST['jam_brngkt']."')";

mysqli_query($koneksi, $sql) or exit ("Error query :".$sql);
echo"berhasil menambhkan data";
header('location: tampilpesan.php');
?>