<html>
<head>
<title>TTravel</title>
</head>
<body>

<div id="main">
	<div class="content">
		<h3>Tampil Data</h3>
<table id="tabel"  border="1" cellpadding="3" >
	<tr>
		<th style="width: 100px;">Nama</th>
		<th style="width: 50px;">Email</th>
		<th style="width: 100px;">no hp</th>
		<th style="width: 140px;">tujuan</th>
		<th>tanggal pesan</th>
		<th>tanggal berangkat</th>
		<th style="width: 100px;">jam berangkat</th>
	</tr>
	<?php include('db.php'); 
	$sql = "SELECT * FROM pemesanan "; 
	$hasil=mysqli_query($koneksi,$sql) or die(mysqli_error());
	$no=1;
	while ($row=mysqli_fetch_array($hasil))
{$nama_pemesan=$row['nama_pemesan'];
$alamat_email=$row['alamat_email'];
$no_hp=$row['no_hp'];
$tujuan=$row['tujuan'];
$tanggal_psn=$row['tanggal_psn'];
$tanggal_brngkt=$row['tanggal_brngkt'];
$jam_brngkt=$row['jam_brngkt'];

		?>
		<tr>

			
			<td><?php echo $nama_pemesan; ?></td>
			<td><?php echo $alamat_email;?></td>
			<td><?php echo $no_hp; ?></td>
			<td><?php echo $tujuan; ?></td>
			<td><?php echo $tanggal_psn; ?></td>
                  <td><?php echo $tanggal_brngkt; ?></td>
			<td><?php echo $jam_brngkt; ?></td>
			
		</tr>
		<?php } ?>
	</table>
</div>
</div>
<a href="index.php">Input Data Lagi</a>
</pre>
</body>
</html>

